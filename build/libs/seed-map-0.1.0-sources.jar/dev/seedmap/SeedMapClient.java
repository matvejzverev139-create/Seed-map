package dev.seedmap;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class SeedMapClient implements ClientModInitializer {
    public static final String MOD_ID = "seed_map";
    private static class_304 openMapKey;
    private static long lastKnownSeed;
    private static boolean hasKnownSeed;

    @Override
    public void onInitializeClient() {
        openMapKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.seed_map.open", class_3675.class_307.field_1668, GLFW.GLFW_KEY_M,
                class_304.class_11900.method_74698(class_2960.method_60655(MOD_ID, "main"))));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMapKey.method_1436()) {
                client.method_1507(new SeedMapScreen(client.field_1755));
            }
            updateSeedFromIntegratedServer(client);
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            class_310 client = class_310.method_1551();
            if (client.field_1724 == null || client.field_1690.field_1842 || client.field_1755 != null) {
                return;
            }
            String status = hasKnownSeed ? "Seed Map: " + lastKnownSeed + "  [M]" : "Seed Map: press [M] and enter a seed";
            drawContext.method_27535(client.field_1772, class_2561.method_43470(status), 8, 8, 0xD8E7E5);
        });
    }

    private static void updateSeedFromIntegratedServer(class_310 client) {
        if (client.method_1576() != null && client.field_1687 != null) {
            lastKnownSeed = client.method_1576().method_30002().method_8412();
            hasKnownSeed = true;
        }
    }

    public static long getKnownSeed() {
        return lastKnownSeed;
    }

    public static boolean hasKnownSeed() {
        return hasKnownSeed;
    }

    public static void rememberSeed(long seed) {
        lastKnownSeed = seed;
        hasKnownSeed = true;
    }

    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }
}
