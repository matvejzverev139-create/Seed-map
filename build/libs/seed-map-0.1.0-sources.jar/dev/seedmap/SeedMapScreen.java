package dev.seedmap;

import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class SeedMapScreen extends class_437 {
    private final class_437 parent;
    private class_342 seedField;
    private WorldDimension dimension = WorldDimension.OVERWORLD;
    private List<StructureCandidate> candidates = List.of();
    private int centerChunkX;
    private int centerChunkZ;

    public SeedMapScreen(class_437 parent) {
        super(class_2561.method_43470("Seed Map"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int left = 22;
        seedField = new class_342(field_22793, left, 30, 260, 20, class_2561.method_43470("World seed"));
        seedField.method_1852(SeedMapClient.hasKnownSeed() ? Long.toString(SeedMapClient.getKnownSeed()) : "");
        seedField.method_47404(class_2561.method_43470("Enter world seed"));
        method_37063(seedField);
        method_37063(class_4185.method_46430(class_2561.method_43470("Locate"), button -> locate())
                .method_46434(left + 268, 30, 78, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Overworld"), button -> select(WorldDimension.OVERWORLD))
                .method_46434(left, 58, 106, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Nether"), button -> select(WorldDimension.NETHER))
                .method_46434(left + 112, 58, 106, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("End"), button -> select(WorldDimension.END))
                .method_46434(left + 224, 58, 106, 20).method_46431());
        if (SeedMapClient.hasKnownSeed()) {
            locate();
        }
    }

    private void select(WorldDimension next) {
        dimension = next;
        locate();
    }

    private void locate() {
        long seed;
        try {
            seed = Long.parseLong(seedField.method_1882().trim());
        } catch (NumberFormatException ignored) {
            candidates = List.of();
            return;
        }
        SeedMapClient.rememberSeed(seed);
        class_310 client = class_310.method_1551();
        class_2338 pos = client.field_1724 == null ? class_2338.field_10980 : client.field_1724.method_24515();
        centerChunkX = pos.method_10263() >> 4;
        centerChunkZ = pos.method_10260() >> 4;
        candidates = SeedMapLocator.locate(seed, dimension.key, centerChunkX, centerChunkZ, 512);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        context.method_25294(12, 12, field_22789 - 12, field_22790 - 12, 0xE91A2428);
        context.method_27535(field_22793, field_22785, 22, 18, 0xF4E9D8);
        context.method_27535(field_22793, class_2561.method_43470("Dimension: " + dimension.label), 22, 88, 0xB7D5CF);
        drawMap(context);
        context.method_27535(field_22793, class_2561.method_43470("M: close   |   click a marker for coordinates"), 22, field_22790 - 24, 0x9EB7B1);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void drawMap(class_332 context) {
        int mapLeft = 370;
        int mapTop = 30;
        int mapRight = field_22789 - 28;
        int mapBottom = field_22790 - 38;
        context.method_25294(mapLeft, mapTop, mapRight, mapBottom, 0xFF26383A);
        for (int x = mapLeft; x < mapRight; x += 32) {
            context.method_25294(x, mapTop, x + 1, mapBottom, 0x183F6260);
        }
        for (int y = mapTop; y < mapBottom; y += 32) {
            context.method_25294(mapLeft, y, mapRight, y + 1, 0x183F6260);
        }
        int centerX = (mapLeft + mapRight) / 2;
        int centerY = (mapTop + mapBottom) / 2;
        context.method_25294(centerX - 3, centerY - 3, centerX + 4, centerY + 4, 0xFFF0C674);
        int scale = Math.max(1, Math.min(mapRight - mapLeft, mapBottom - mapTop) / 1024);
        for (int index = 0; index < candidates.size(); index++) {
            StructureCandidate candidate = candidates.get(index);
            int x = centerX + (candidate.chunkX() - centerChunkX) * scale;
            int y = centerY + (candidate.chunkZ() - centerChunkZ) * scale;
            if (x < mapLeft + 4 || x > mapRight - 4 || y < mapTop + 4 || y > mapBottom - 4) {
                continue;
            }
            int color = 0xFF6CC0A8 + (index % 3) * 0x00101000;
            context.method_25294(x - 3, y - 3, x + 4, y + 4, color);
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }

    private enum WorldDimension {
        OVERWORLD("Overworld", class_1937.field_25179),
        NETHER("Nether", class_1937.field_25180),
        END("End", class_1937.field_25181);

        private final String label;
        private final net.minecraft.class_5321<class_1937> key;

        WorldDimension(String label, net.minecraft.class_5321<class_1937> key) {
            this.label = label;
            this.key = key;
        }
    }
}
